 
  <h4><?php echo e($loop->iteration); ?> - <?php echo $article->Name_formated; ?></h4> 
  <h4><?php echo str_limit($article->body_formated,200,'..... <a href="#">à suivre</a> <a href="/articles/create">modifier</a> '); ?> </h4>
 
  <!-- str_limit permet la limitation d'affichage au nombre de caractère -->
 
  <h4>la relation entre article est user : email - <?php echo $article->user->email; ?></h4> 

    <?php $__env->startComponent('components.bouton'); ?>
    lire la suite 
    <?php echo $__env->renderComponent(); ?>