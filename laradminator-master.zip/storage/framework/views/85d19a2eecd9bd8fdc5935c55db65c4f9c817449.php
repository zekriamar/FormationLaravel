<?php $__env->startSection('titreart'); ?>
 Zekri index article
 <?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
 <link rel="stylesheet" href="style.css">
 <style>
    @media  print{
     .hidden-print{display:none}
     .full-height {height: initial!important}
     /* <ul>display:non</ul> */
    }

 </style>
 
 <?php $__env->stopSection(); ?>

<?php $__env->startSection('mainName'); ?>

<button class="hidden-print" onClick="window.print()"> Print </button>

<form action="" class="form-inline">
 <input type="search" value="<?php echo e(request('search')); ?>" class="form-control" name="search" placeholder="Recherche...">
 <button type="submit" class="btn btn-warning" > <i class="fa fa-search"></i> </button>
</form>
<h1> Liste articles </h1>

 <?php $__empty_1 = true; $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?> 
 <!-- <?php if($loop->first): ?> Premier élément 
 <?php endif; ?>
 <?php if($loop->last): ?> Dernier élément
 <?php endif; ?> -->
 <?php echo $__env->make('articles._article', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
  <h4>pas d'articles</h4>
 <?php endif; ?>

 <!-- <?php echo e($articles->render()); ?> //affichage des pages -->
 <?php echo e($articles->appends(['search'=>request('search')])->links()); ?> //affichage des pages seconde page

 //appends permet de garder le réseault de recherche me^me en changeant la page
 <?php $__env->stopSection(); ?>

<?php echo $__env->make('welcome', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>