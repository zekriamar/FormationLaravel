<li class="nav-item mT-30 active">
    <a class='sidebar-link' href="<?php echo e(route(ADMIN . '.dash')); ?>" default>
        <span class="icon-holder">
            <i class="c-blue-500 ti-home"></i>
        </span>
        <span class="title">Dashboard</span>
    </a>
</li>
<li class="nav-item">
    <a class='sidebar-link' href="<?php echo e(route(ADMIN . '.users.index')); ?>">
        <span class="icon-holder">
            <i class="c-brown-500 ti-user"></i>
        </span>
        <span class="title">Users</span>
    </a>
</li>
