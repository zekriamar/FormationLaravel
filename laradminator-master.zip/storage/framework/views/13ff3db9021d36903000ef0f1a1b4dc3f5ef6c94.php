<?php $__env->startSection('page-header'); ?>
	User <small><?php echo e(trans('app.update_item')); ?></small>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<?php echo Form::model($item, [
			'action' => ['UserController@update', $item->id],
			'method' => 'put', 
			'files' => true
		]); ?>


		<?php echo $__env->make('admin.users.form', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

		<button type="submit" class="btn btn-primary"><?php echo e(trans('app.edit_button')); ?></button>
		
	<?php echo Form::close(); ?>

	
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.default', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>