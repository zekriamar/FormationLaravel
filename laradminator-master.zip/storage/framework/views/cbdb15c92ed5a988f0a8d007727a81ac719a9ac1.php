<?php $__env->startSection('mainName'); ?>

<div class="container" >

<?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>

<form action="<?php echo e(route('articles.store')); ?>" method="POST"> 
    <?php echo csrf_field(); ?>
    <input type="text" name="name" class ="form-control <?php echo e($errors->has('name') ? 'is-invalid' :''); ?>" value="<?php echo e(old('name')); ?> " placeholder="Nom" > <br>
    <input type="date" name="published_at" class ="form-control <?php echo e($errors->has('published_at')? 'is-invalid' :''); ?>" value="<?php echo e(old('published_at')); ?> " placeholder="Date de publication"><br>
    <textarea name="body" class ="form-control  <?php echo e($errors->has('body')? 'is-invalid' :''); ?>" placeholder="body" > <?php echo e(old('body')); ?> </textarea > <br> 
    <button type="submit" class="btn btn-info" > Ajouter </button>
</form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('welcome', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>